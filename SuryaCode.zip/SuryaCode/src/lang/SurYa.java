package lang;

public class SurYa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Surya");

	}

}
